use strict;

my $trio_snv_vcf=shift;


print "####  Ref : -> Father\n";
print "####  SNP : -> Mother\n";
print "SNP-ID\tChromosome\tPosition\tStrand\tRef/SNP\n";


open IN,"<","$trio_snv_vcf" or die;
while(<IN>){
	chomp;
	next if /^#/;
	my @a=split /\t/,$_;
	my $geno1=(split /:/,$a[11])[0];
	my $geno2=(split /:/,$a[9])[0];
	my $geno3=(split /:/,$a[10])[0];
	
	next unless ($geno3 eq '0/1');
	
	next if ($geno1 eq $geno2);
	
	my $snv_id="$a[0].$a[1]";

	if($geno1 eq '0/0'){
		print "$snv_id\t$a[0]\t$a[1]\t1\t$a[3]/$a[4]\n";
	}elsif($geno1 eq '1/1'){
		print "$snv_id\t$a[0]\t$a[1]\t1\t$a[4]/$a[3]\n";
	}else{
		if($geno2 eq '1/1'){
			print "$snv_id\t$a[0]\t$a[1]\t1\t$a[3]/$a[4]\n";
		}else{
			print "$snv_id\t$a[0]\t$a[1]\t1\t$a[4]/$a[3]\n";
		}
	}
}
close IN;



